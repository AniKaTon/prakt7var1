 document.getElementById('w1').onclick = function(){
	
	 document.getElementById('vi').innerHTML="<video type='mp4' width='1800' height='919'src='Land.mp4' controls='controls'></video>'";
}
function _go() {
    location.href=document.getElementById('address').options[document.getElementById('address').selectedIndex].value;
}